/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareacompiladores;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author Ignacio
 */
public class Generadoor {
    /* 
    Clase generadora de los archivos Yylex,parser y sym, los cuales ayudaran en la implementacion del
    traductor dirigido por sintaxis.
    Esto produce que al compilar esta clase, en la carpeta del proyecto, especificamente en la carpeta 
    src, se generen los archivos anteriormente mencionados.
    */
      public static void main(String[] args) {
                    System.out.println("\n*** Generando ***\n");
                    //Busca los archivos lexico y sintactios
                    /*
                    En este caso se usan los que vienen por defecto, alexico.flex
                    y asintactico.cup (Archivos que se crearon).
                    */
                    String archLexico = "";
                    String archSintactico = "";
                    if (args.length > 0) {
                        System.out.println("\n*** Procesando archivos custom ***\n");
                        archLexico = args[0];
                        archSintactico = args[1];
                    } else {
                        System.out.println("\n*** Procesando archivo default ***\n");
                        archLexico = "alexico.flex";
                        archSintactico = "asintactico.cup";
                    }
                    /*
                    Estos archivos los coloca dentro de una matriz
                    */
                    String[] alexico = {archLexico};
                    /*
                    Se indica que queremos generar un -parser que es un analizador sintactico,
                    el cual tendra el nombre de parser y se le pasa finalmente el archivo.
                    */
                    String[] asintactico = {"-parser", "parser", archSintactico};
                    jflex.Main.main(alexico);
                    /*
                    Luego se pasa el archivo del analisador sintactico que se desea generar,
                    se pasan a la clase java_cup, el cual posee una clase llamada "Main",
                    el cual tiene un metodo llamado "main"
                    */
                    try {
                        java_cup.Main.main(asintactico);
                    } catch (Exception ex) {
                        Logger.getLogger(TareaCompiladores.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    //Finalmente se mueven los archivos generados
                    boolean mvAL = moverArch("Yylex.java");
                    boolean mvAS = moverArch("parser.java");
                    boolean mvSym= moverArch("sym.java");
                    if(mvAL && mvAS && mvSym){
                       System.exit(0);
                    }
                    System.out.println("Generado!");
                    
        
      
      }
      /*
      Este metodo hace que se muevan los archivos a la carpeta src del proyecto, ya que al 
      generarlos se almacenan directamente en la raiz.
      
      */
        public static boolean moverArch(String archNombre){
        boolean efectuado = false;
        File arch = new File(archNombre);
        if (arch.exists()) {
            System.out.println("\n*** Moviendo " + arch + " \n***");
            Path currentRelativePath = Paths.get("");
            String nuevoDir = currentRelativePath.toAbsolutePath().toString()
                    + File.separator + "src" + File.separator
                    + "tareacompiladores" + File.separator + arch.getName();
            File archViejo = new File(nuevoDir);
            archViejo.delete();
            if (arch.renameTo(new File(nuevoDir))) {
                System.out.println("\n*** Generado " + archNombre + "***\n");
                efectuado = true;
            } else {
                System.out.println("\n*** No movido " + archNombre + " ***\n");
            }

        } else {
            System.out.println("\n*** Codigo no existente ***\n");
        }
        return efectuado;
    }
}
