package tareacompiladores;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ignacio
 */
public class TareaCompiladores {
    public final static int EJECUTAR = 1;
    public final static int SALIR = 2;

//Clase para dar inicio a la ejecucion del programa 
   public static void main(String[] args) throws Exception {
       
        java.util.Scanner in = new Scanner(System.in);
        int valor = 0;
              do {
                  
            System.out.println("*****************************************Traductor Sintactico*****************************************");
            System.out.println("INSTRUCCIONES Y RESTRICCIONES DE USO"); 
            System.out.println("IMPORTANTE!: LEER TODO ANTES DE EMPEZAR A UTILIZAR"); 
            System.out.println(" -Para iniciar, primero se debe elegir la opción 1. A continuación se deberá ingresar la palabra");
            System.out.println("'inicio', escrita en minúscula. Luego de esto se podrán implementar las siguientes operaciones: ");
            System.out.println(" -Asignar valor a una variable, ejemplo A = 10. La variable corresponde a una letra en mayúscula.");
            System.out.println(" -Leer una variable, ejemplo leer(B) y a continuación ingresar su valor.");
            System.out.println(" -Escribir('texto' o 'variable') en pantalla, ejemplo escribir('Hola mundo'), donde texto es ");
            System.out.println("cualquier cadena de caracteres. Y variable corresponde a un dato ingresado con anterioridad.");
            System.out.println(" -Además se pueden implementar instrucciones condicionales usando 'si-entonces' (escritas en ");
            System.out.println("minúsculas). Ejemplo si A < 50 entonces escribir('A es menor a 50').");
            System.out.println(" -Para finalizar la ejecución, bastara con introducir la instrucción 'fin', escrita en minúscula.");
            System.out.println("RESTRICCIONES E INDICACIONES:");
            System.out.println("1) Toda instrucción debe ser ingresada en minúscula(inicio, escribir, leer, si, entonces y fin).");
            System.out.println("2) Las variables deben ser letras en mayúsculas.");
            System.out.println("3) Las operaciones que se pueden realizar son suma, resta, división y multiplicación.");
            System.out.println("4) El resultado de todo calculo será truncado, ejemplo 2,65 será solamente 2.");
            System.out.println("5) El rango numerico que se acepta es menor a 10.000.000.000");
            System.out.println("******************************************************************************************************");      
                  
            System.out.println("Elija una opcion: ");
            System.out.println("1) Ejecutar");
            System.out.println("2) Salir");
            System.out.print("Opcion: ");
            valor = in.nextInt();
            
            switch (valor) {
                
                case EJECUTAR: {
                    parser.main(args);
                    
                    break;
                }
                case SALIR: {
                    
                    System.out.println("Chao, Gracias por utilizarme...");
                    
                    break;
                }
                default: {
                    System.out.println("Opcion no valida!");
                    break;
                }
            }
        } while (valor != 2);

    }

}
